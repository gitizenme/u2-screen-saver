MVP release of the iconic U2 flashing word sequence for The Fly. 

This is for Apple macOS only... I don't have the cycles to work on a Windows version.

Installation:

1. Download the [`U2.The.Fly.Screen.Saver.saver.zip`](https://github.com/gitizenme/u2-screen-saver/releases/download/1.0.0/U2.The.Fly.Screen.Saver.saver.zip) file to your computer
2. Double-click on the `.zip` file
3. Double-click on the `.saver` file
4. Clock on install:
<img width="827" alt="image" src="https://github.com/gitizenme/u2-screen-saver/assets/643504/a76e997f-bd81-4968-85b4-26caac377597">
5. Click on the "U2" icon in the list of screen savers:
<img width="827" alt="image" src="https://github.com/gitizenme/u2-screen-saver/assets/643504/89dec888-a434-475c-b6fe-a90925ab99ca">
6. Click on Preview

Enjoy!
